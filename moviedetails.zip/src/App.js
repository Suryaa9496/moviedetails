import React, { useState } from 'react';
import './App.css';
import MovieList from './movielist';
import MovieDetails from './moviedetails';
import moviesData from './moviedata';

function App() {
  const [selectedMovie, setSelectedMovie] = useState(null);

  const handleMovieClick = (movie) => {
    setSelectedMovie(movie);
  };

  return (
    <div className="app">
      <div className="sidebar">
        <h2>Top Movies</h2>
        <MovieList movies={moviesData} onMovieClick={handleMovieClick} />
      </div>
      <div className="main-content">
        <div className="movie-details-container">
          {selectedMovie && <MovieDetails movie={selectedMovie} />}
        </div>
      </div>
    </div>
  );
}

export default App;


