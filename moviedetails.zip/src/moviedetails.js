// MovieDetails.js
import React from 'react';

function MovieDetails({ movie }) {
  return (
    <div>
      <h2>{movie.name}</h2>
      <img class='img' src={movie.image} alt={movie.name} />
      <p>Description: {movie.description}</p>
      <p>Release Year: {movie.releaseYear}</p>
      <p>Cast: {movie.cast.join(', ')}</p>
      <p>IMDB: {movie.imdb}</p>
    </div>
  );
}

export default MovieDetails;
