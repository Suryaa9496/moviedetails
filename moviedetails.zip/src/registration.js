// Registration.js
import React, { useState } from 'react';
import { useHistory } from 'react-router-dom';
import './registration.css'

function Registration() {
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [country, setCountry] = useState('');
  const [dob, setDob] = useState('');
  const [gender, setGender] = useState('');
  const [termsAgreed, setTermsAgreed] = useState(false);
  const history = useHistory();

  const validateForm = (event) => {
    event.preventDefault();

    if (
      !firstName ||
      !lastName ||
      !username ||
      !email ||
      !password ||
      !confirmPassword ||
      !country ||
      !dob ||
      !gender ||
      !termsAgreed
    ) {
      alert("Please fill all the required fields");
      return;
    }

    if (password !== confirmPassword) {
      alert("Passwords do not match");
      return;
    }

    let passwordRegex = /^(?=.*\d)(?=.*[a-zA-Z])(?=.*[^a-zA-Z0-9])\S{8,}$/;

    if (!passwordRegex.test(password)) {
      alert(
        "Password must be at least 8 characters long and include at least one number, one alphabet, and one symbol."
      );
      return;
    }

    // Assuming registration successful, save user data to localStorage
    const user = {
      firstName,
      lastName,
      username,
      email,
      country,
      dob,
      gender,
      password
    };
    localStorage.setItem('user', JSON.stringify(user));
    alert("Registration successful!");
    history.push("/login"); // Redirect to login page
  };

  return (
    <div className="container">
      <form onSubmit={validateForm}>
        <div className="header">
          <h1>Create User</h1>
        </div>
        
        <div className="input-row">
          <label htmlFor="first-name">First name</label>
          <input 
            type="text" 
            id="first-name" 
            placeholder="Enter your First name" 
            value={firstName}
            onChange={(e) => setFirstName(e.target.value)} 
            required 
          />
        </div>
        
        {/* Rest of the form fields go here */}

        <div className="btn">
          <button type="submit">Submit</button>
        </div>
      </form>
    </div>
  );
}

export default Registration;
