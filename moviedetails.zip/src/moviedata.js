// moviesData.js
const moviesData = [
    {
        "name": "Pulp Fiction",
        "image": "https://tse2.mm.bing.net/th/id/OIP.FOFA1UMF6NPXq2EGMnIMQgHaLc?rs=1&pid=ImgDetMain",
        "description": "The lives of two mob hitmen, a boxer, a gangster and his wife, and a pair of diner bandits intertwine in four tales of violence and redemption.",
        "releaseYear": "1994",
        "cast": ["John Travolta", "Uma Thurman", "Samuel L. Jackson"],
        "imdb": "8.9/10"
      },
      {
        "name": "Fight Club",
        "image": "https://tse1.mm.bing.net/th/id/OIP.X8GXwUnJEzAclGg3OtAnrAHaLH?rs=1&pid=ImgDetMain",
        "description": "An insomniac office worker and a devil-may-care soapmaker form an underground fight club that evolves into something much, much more.",
        "releaseYear": "1999",
        "cast": ["Brad Pitt", "Edward Norton", "Helena Bonham Carter"],
        "imdb": "8.8/10"
      },
      {
        "name": "Forrest Gump",
        "image": "https://tse2.mm.bing.net/th/id/OIP.lWBEf0IJLbXegmT9pVdE8QHaJQ?rs=1&pid=ImgDetMain",
        "description": "The presidencies of Kennedy and Johnson, the Vietnam War, the Watergate scandal and other historical events unfold from the perspective of an Alabama man with an IQ of 75, whose only desire is to be reunited with his childhood sweetheart.",
        "releaseYear": "1994",
        "cast": ["Tom Hanks", "Robin Wright", "Gary Sinise"],
        "imdb": "8.8/10"
      },
      {
        "name": "The Matrix",
        "image": "https://tse3.mm.bing.net/th/id/OIP.BthwaDFzOiwwut5b3y84eQHaK9?rs=1&pid=ImgDetMain",
        "description": "A computer hacker learns from mysterious rebels about the true nature of his reality and his role in the war against its controllers.",
        "releaseYear": "1999",
        "cast": ["Keanu Reeves", "Laurence Fishburne", "Carrie-Anne Moss"],
        "imdb": "8.8/10"
      },
      {
        "name": "The Godfather",
        "image": "https://tse1.mm.bing.net/th/id/OIP.8aQ44AHmvs2UxTggpgM2tQHaKh?rs=1&pid=ImgDetMain",
        "description": "The aging patriarch of an organized crime dynasty transfers control of his clandestine empire to his reluctant son.",
        "releaseYear": "1972",
        "cast": ["Marlon Brando", "Al Pacino", "James Caan"],
        "imdb": "9.2/10"
      },
      {
        "name": "The Lord of the Rings: The Fellowship of the Ring",
        "image": "https://th.bing.com/th/id/R.fb2c88280826db314e2f906605e9be1f?rik=Kni10fia6XAT0A&riu=http%3a%2f%2fwww.pastposters.com%2fcw3%2fassets%2fproduct_expanded%2f(JamieR-HK)__LOTR-Fellowship(3).jpg&ehk=J1NxvAuKGBqJdLAdYXDDeBF6s6J1FMHT2UFabwoWXgg%3d&risl=&pid=ImgRaw&r=0",
        "description": "A meek Hobbit from the Shire and eight companions set out on a journey to destroy the powerful One Ring and save Middle-earth from the Dark Lord Sauron.",
        "releaseYear": "2001",
        "cast": ["Elijah Wood", "Ian McKellen", "Viggo Mortensen"],
        "imdb": "8.9/10"
      },
      {
        "name": "The Silence of the Lambs",
        "image": "https://cdn.shopify.com/s/files/1/1416/8662/products/silence_of_the_lambs_1990_styleA_teaser_original_film_art_f_2000x.jpg?v=1555770913",
        "description": "A young FBI cadet must receive the help of an incarcerated and manipulative cannibal killer to help catch another serial killer, a madman who skins his victims.",
        "releaseYear": "1991",
        "cast": ["Jodie Foster", "Anthony Hopkins", "Scott Glenn"],
        "imdb": "8.6/10"
      },
      {
        "name": "Goodfellas",
        "image": "https://tse3.mm.bing.net/th/id/OIP.68IXs-nPe_s2W-ez7p_y8wHaLG?rs=1&pid=ImgDetMain",
        "description": "The story of Henry Hill and his life in the mob, covering his relationship with his wife Karen Hill and his mob partners Jimmy Conway and Tommy DeVito in the Italian-American crime syndicate.",
        "releaseYear": "1990",
        "cast": ["Robert De Niro", "Ray Liotta", "Joe Pesci"],
        "imdb": "8.7/10"
      },
      {
        "name": "Schindler's List",
        "image": "https://is4-ssl.mzstatic.com/image/thumb/JkLxOic-66dh2JVWWduCyA/1200x675.jpg",
        "description": "In German-occupied Poland during World War II, industrialist Oskar Schindler gradually becomes concerned for his Jewish workforce after witnessing their persecution by the Nazis.",
        "releaseYear": "1993",
        "cast": ["Liam Neeson", "Ben Kingsley", "Ralph Fiennes"],
        "imdb": "9/10"
      },
      {
        "name": "The Shawshank Redemption",
        "image": "https://tse1.mm.bing.net/th/id/OIP.mA5SG8RpkLC4PvEhT45igAHaKr?rs=1&pid=ImgDetMain",
        "description": "Two imprisoned men bond over a number of years, finding solace and eventual redemption through acts of common decency.",
        "releaseYear": "1994",
        "cast": ["Tim Robbins", "Morgan Freeman", "Bob Gunton"],
        "imdb": "9.3/10"
      },
      {
        "name": "Gladiator",
        "image": "https://tse1.mm.bing.net/th/id/OIP.oT-J5053ZbyMPq9IGpobqQHaLH?rs=1&pid=ImgDetMain",
        "description": "A former Roman General sets out to exact vengeance against the corrupt emperor who murdered his family and sent him into slavery.",
        "releaseYear": "2000",
        "cast": ["Russell Crowe", "Joaquin Phoenix", "Connie Nielsen"],
        "imdb": "8.5/10"
      },
      {
        "name": "Interstellar",
        "image": "https://tse1.mm.bing.net/th/id/OIP.PHz1k99MkFZFAkMIafFQ-gHaHa?rs=1&pid=ImgDetMain",
        "description": "A team of explorers travel through a wormhole in space in an attempt to ensure humanity's survival.",
        "releaseYear": "2014",
        "cast": ["Matthew McConaughey", "Anne Hathaway", "Jessica Chastain"],
        "imdb": "8.7/10"
      },
      {
        "name": "The Departed",
        "image": "https://tse4.mm.bing.net/th/id/OIP.kcWp64Tn4r7Wi-YsBabfuQHaK-?rs=1&pid=ImgDetMain",
        "description": "An undercover cop and a mole in the police attempt to identify each other while infiltrating an Irish gang in South Boston.",
        "releaseYear": "2006",
        "cast": ["Leonardo DiCaprio", "Matt Damon", "Jack Nicholson"],
        "imdb": "8.6/10"
      },
      {
        "name": "The Green Mile",
        "image": "https://i.ytimg.com/vi/gWRkShB80K4/maxresdefault.jpg",
        "description": "The lives of guards on Death Row are affected by one of their charges: a black man accused of child murder and rape, yet who has a mysterious gift.",
        "releaseYear": "1999",
        "cast": ["Tom Hanks", "Michael Clarke Duncan", "David Morse"],
        "imdb": "8.6/10"
      }
   
  ];
  
  export default moviesData;
  