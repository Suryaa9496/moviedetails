// Login.js
import React, { useState } from 'react';
import { useHistory } from 'react-router-dom'; // Assuming you're using React Router for navigation
import './login.css'

function Login() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const history = useHistory();

  const checkFields = (event) => {
    event.preventDefault(); 

    
    const dummyUser = {
      username: 'testUser',
      password: 'testPassword'
    };

    if (username === dummyUser.username && password === dummyUser.password) {
      alert("Login successful!"); 
     
    } else {
      alert("Invalid username or password");
    }
  };

  return (
    <div className="container">
      <form onSubmit={checkFields}>
        <h1>User Login</h1>
        
        <div className="input-row">
          <label htmlFor="username">Username</label>
          <input 
            type="text" 
            id="username" 
            placeholder="Enter your username" 
            value={username}
            onChange={(e) => setUsername(e.target.value)} 
            required 
          /> 
        </div>
    
        <div className="input-row">
          <label htmlFor="password" className="password">Password </label>  
          <input 
            type="password" 
            id="password" 
            placeholder="Enter your password" 
            value={password}
            onChange={(e) => setPassword(e.target.value)} 
            required 
          />
        </div>  

        <div className="btn">
          <button id="button" type="submit">Submit</button>
        </div>
      </form>
    </div>
  );
}

export default Login;
