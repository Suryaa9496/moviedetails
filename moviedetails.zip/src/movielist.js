
// MovieList.js
import React from 'react';

function MovieList({ movies, onMovieClick }) {
  return (
    <ul>
      {movies.map((movie, index) => (
        <li key={index} onClick={() => onMovieClick(movie)}>
          {movie.name}
        </li>
      ))}
    </ul>
  );
}

export default MovieList;
